                <footer>
                    <div class="">
                        <p class="pull-right">©<?php echo date("Y");?> All Rights Reserved. Powered by
                            <a href="http://geeksntechnology.com/" target="_blank"><span class="lead"> <i class="fa fa-slack"></i> Geeksntechnology.com</span></a>
                        </p>
                    </div>
                    <div class="clearfix"></div>
                </footer>